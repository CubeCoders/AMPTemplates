#!/bin/bash
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# start-mock-k8s.sh BASE_DIR
#
# Launches the minimal Kubernetes API mock that intercepts director's
# on-demand ServerSetScale CR ops and turns them into start-ue5.sh
# invocations against a pre-allocated port pool.

BASE="${1:-${DUNE_BASE_DIR:-}}"
# AMP supplies the startup-auth token via $AMPToken substitution,
# only in command-line contexts (not env). We receive it as $2 and
# export it so the env-block below can hand it to mock-k8s-go.
AMP_TOKEN="${2:-}"
export AMP_TOKEN
export SOURCE="mock-k8s"
source "$(dirname "$(readlink -f "$0")")/lib.sh" "$BASE"

log "Starting mock Kubernetes API on 127.0.0.1:$K8S_MOCK_PORT (port pool size $K8S_POOL_SIZE)..."

_logsz=$(stat -c %s "$LOGS/mock-k8s.log" 2>/dev/null || echo 0)
launch_bg mock-k8s "$LOGS/mock-k8s.log" -- \
  env PYTHONUNBUFFERED=1 \
      AMP_TOKEN="$AMP_TOKEN" \
      K8S_MOCK_PORT="$K8S_MOCK_PORT" \
      K8S_POOL_SIZE="$K8S_POOL_SIZE" \
      K8S_POOL_GAME_PORT_BASE="${K8S_POOL_GAME_PORT_BASE:-7900}" \
      K8S_POOL_IGW_PORT_BASE="$K8S_POOL_IGW_PORT_BASE" \
      DUNE_DIRECTOR_PORT="$DUNE_DIRECTOR_PORT" \
      DUNE_GATEWAY_PORT="$DUNE_GATEWAY_PORT" \
      DUNE_WORLD_NAME="$DUNE_WORLD_NAME" \
      DUNE_BIND_IP="$DUNE_BIND_IP" \
      DUNE_PG_PORT="$DUNE_PG_PORT" \
      DUNE_BASE_DIR="$BASE" \
  "$SCRIPTS/mock-k8s-go" "$BASE"

# Wait for THIS run's "ready" line (logged only after the listener is bound)
# rather than for the port to answer: a foreign listener (e.g. a host k3s
# on 6443) used to satisfy the port check while mock-k8s had died on
# "address already in use", and director then talked to the wrong API.
# Startup includes the world_partition sync, so allow a minute.
_ok=0
for _i in $(seq 1 60); do
  _new=$(tail -c +$((_logsz + 1)) "$LOGS/mock-k8s.log" 2>/dev/null)
  case "$_new" in
    *"Mock Kubernetes API ready"*) _ok=1; break ;;
    *"server failed"*|*"[ERROR]"*) break ;;
  esac
  sleep 1
done
if [ "$_ok" = 1 ]; then
  log "Mock Kubernetes API ready: success on 127.0.0.1:$K8S_MOCK_PORT (pid $(read_pid mock-k8s))"
else
  tail -30 "$LOGS/mock-k8s.log" >&2
  die "Mock Kubernetes API failed to start (see mock-k8s.log above)"
fi
