#!/usr/bin/env python3
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# ini-merge.py SHIPPED ADMIN PRISTINE
#
# Carry an admin-edited copy of a Funcom INI (director_config.ini) forward
# onto a newer shipped version. Funcom adds maps/keys between releases; an
# admin copy seeded once from an old release silently lacks them (1.5:
# director rejected the five new maps as "unrecognized").
#
#   * PRISTINE (the shipped file ADMIN was last merged from) present:
#     3-way - keys the admin changed/added vs PRISTINE win; everything else
#     comes from SHIPPED, so Funcom's default changes also flow through.
#   * PRISTINE missing (installs older than v19): 2-way - ADMIN values win
#     wherever they differ from SHIPPED; SHIPPED-only sections/keys are added.
#
# Writes the merged result over ADMIN and copies SHIPPED to PRISTINE.
# Line-based and order-preserving (SHIPPED's layout, comments and CRLF kept);
# keys are matched per section, case-sensitively, trimmed of whitespace.
import os, re, shutil, sys

SEC = re.compile(r'^\s*\[\s*(.*?)\s*\]\s*$')
KEY = re.compile(r'^\s*([^;#=\s][^=]*?)\s*=(.*)$')


def parse(path):
    out, sec = {}, ''
    with open(path, encoding='utf-8-sig', newline='') as f:
        for raw in f:
            line = raw.rstrip('\r\n')
            m = SEC.match(line)
            if m:
                sec = m.group(1)
                out.setdefault(sec, {})
                continue
            m = KEY.match(line)
            if m:
                out.setdefault(sec, {})[m.group(1)] = m.group(2)
    return out


def val(v):
    # compare values ignoring trailing ";" comments and whitespace
    return re.split(r'\s*;', v, maxsplit=1)[0].strip()


def main():
    shipped, admin, pristine = sys.argv[1:4]
    S, A = parse(shipped), parse(admin)
    P = parse(pristine) if os.path.exists(pristine) else None
    base = P if P is not None else S

    keep = {}  # sec -> {key: raw value} the admin owns
    for sec, kv in A.items():
        for k, v in kv.items():
            b = base.get(sec, {}).get(k)
            if b is None or val(b) != val(v):
                keep.setdefault(sec, {})[k] = v

    with open(shipped, encoding='utf-8-sig', newline='') as f:
        lines = f.read().splitlines(keepends=True)
    eol = '\r\n' if any(l.endswith('\r\n') for l in lines) else '\n'
    if lines and not lines[-1].endswith(('\n', '\r')):
        lines[-1] += eol

    out, done = [], set()

    def flush(sec):
        for k, v in keep.get(sec, {}).items():
            if (sec, k) not in done:
                out.append(f'{k}={v}{eol}')
                done.add((sec, k))

    sec = ''
    for raw in lines:
        line = raw.rstrip('\r\n')
        m = SEC.match(line)
        if m:
            flush(sec)
            sec = m.group(1)
        else:
            m = KEY.match(line)
            if m and m.group(1) in keep.get(sec, {}):
                out.append(f'{m.group(1)}={keep[sec][m.group(1)]}{eol}')
                done.add((sec, m.group(1)))
                continue
        out.append(raw)
    flush(sec)
    for s in keep:  # admin-only sections
        if s not in S and any((s, k) not in done for k in keep[s]):
            out.append(f'{eol}[ {s} ]{eol}')
            flush(s)

    tmp = admin + '.tmp'
    with open(tmp, 'w', encoding='utf-8', newline='') as f:
        f.writelines(out)
    os.replace(tmp, admin)
    shutil.copyfile(shipped, pristine)
    n = sum(len(v) for v in keep.values())
    print(f'merged {os.path.basename(shipped)}: kept {n} admin value(s), '
          f'{"3-way" if P is not None else "2-way (no baseline)"}')


main()
