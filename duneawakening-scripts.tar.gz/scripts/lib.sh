#!/bin/bash
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# lib.sh - Shared helpers for the AMP Dune Awakening template scripts.
#
# Sourced by every other script. Establishes layout variables, logging,
# env loading, PID-file management, and wait-for-port helpers.
#
# Layout under $BASE (passed as $1 to each script, or DUNE_BASE_DIR env):
#   $BASE/scripts/        — these scripts
#   $BASE/depot/          — SteamCMD download
#   $BASE/extracted/      — OCI rootfs trees (postgres/, mq/, director/, ...)
#   $BASE/state/          — persistent identity + data (pg/data, ue5-saved, certs)
#   $BASE/runtime/        — regenerated each start (pids, conf, sockets)
#   $BASE/logs/           — per-service log files

set -eu             # pipefail deliberately omitted: many pipelines `| head` or `| tail`
                    # which SIGPIPE the producer, which under pipefail aborts the script.

# --------------------------------------------------------------------------
# BASE layout
# --------------------------------------------------------------------------
BASE="${1:-${DUNE_BASE_DIR:-}}"
[ -n "$BASE" ] || { echo "lib.sh: BASE dir missing (arg1 or DUNE_BASE_DIR)"; exit 1; }
BASE="${BASE%/}"
export DUNE_BASE_DIR="$BASE"

SCRIPTS="$BASE/scripts"
DEPOT="$BASE/depot"
EXTRACTED="$BASE/extracted"
STATE="$BASE/server/state"
RUNTIME="$BASE/runtime"
LOGS="$BASE/logs"
TEMPLATES="$SCRIPTS/templates"

mkdir -p "$STATE" "$RUNTIME/pids" "$RUNTIME/postgresql" "$LOGS" 2>/dev/null || true

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
# SOURCE is the structured-log [source] tag for this script.
# Each script sets SOURCE before sourcing lib.sh; fall back to 'amp'.
: "${SOURCE:=amp}"
log()  { printf '[%s] [INFO] %s\n'  "$SOURCE" "$*"; }
warn() { printf '[%s] [WARN] %s\n'  "$SOURCE" "$*" >&2; }
die()  { printf '[%s] [ERROR] %s\n' "$SOURCE" "$*" >&2; exit 1; }

# --------------------------------------------------------------------------
# Per-service rootfs paths + LD_LIBRARY_PATH builder
# --------------------------------------------------------------------------
rootfs()  { echo "$EXTRACTED/$1"; }
ldlib()   { local r; r=$(rootfs "$1"); echo "$r/lib:$r/usr/lib:$r/usr/local/lib"; }
ldlib_mq() { echo "$(ldlib mq):$EXTRACTED/mq/opt/openssl/lib"; }
icu_dir() {
  # find icudt74l.dat (74.1 in some images, 74.2 in others)
  local r; r=$(rootfs "$1")
  local d; d=$(find "$r/usr/share/icu" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | head -1)
  echo "${d:-$r/usr/share/icu/74.2}"
}

# --------------------------------------------------------------------------
# PID-file helpers (used by start scripts AND console.sh on shutdown)
# --------------------------------------------------------------------------
pid_file() { echo "$RUNTIME/pids/$1.pid"; }

write_pid() {
  local name=$1 pid=$2
  echo "$pid" > "$(pid_file "$name")"
}

read_pid() {
  local f; f=$(pid_file "$1") pid=""
  [ -f "$f" ] && pid=$(cat "$f" 2>/dev/null)
  # Validate: empty / non-numeric / dead -> return empty so callers
  # don't act on a phantom from a stale file.
  case "$pid" in ''|*[!0-9]*) echo ""; return ;; esac
  kill -0 "$pid" 2>/dev/null && echo "$pid" || echo ""
}

is_running() {
  local pid; pid=$(read_pid "$1")
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

# --------------------------------------------------------------------------
# Launch helper — runs a command in the background, captures stdout+stderr
# to a service log, records PID for later shutdown.  Returns immediately.
# Usage: launch_bg <name> <log_file> -- <cmd...>
# --------------------------------------------------------------------------
launch_bg() {
  local name=$1 logf=$2; shift 2
  [ "$1" = "--" ] && shift
  log "starting $name"
  # setsid forks before exec, so $! gives us the short-lived setsid
  # wrapper PID — useless for shutdown. Instead, run an inner bash
  # inside the new session that writes its OWN $$ (the new session
  # leader's PID == PGID) to the pid file, then execs the real binary.
  # After exec the PID/PGID are preserved, so shutdown sees the right
  # value forever.
  local pidf; pidf=$(pid_file "$name")
  setsid bash -c 'echo $$ > "$1"; shift; exec "$@"' _ "$pidf" "$@" \
      >>"$logf" 2>&1 < /dev/null &
  disown
}

# purge_pids — wipe any pid files left over from a previous incarnation
# of this instance. Without this, a stale value (PID reused for an
# unrelated process) could let console.sh's shutdown_all signal the
# wrong target. Called from prestart.sh before any launch_bg.
purge_pids() {
  mkdir -p "$RUNTIME/pids"
  rm -f "$RUNTIME/pids/"*.pid 2>/dev/null || true
}

# --------------------------------------------------------------------------
# wait_for_port host port timeout_sec
# --------------------------------------------------------------------------
wait_for_port() {
  local host=$1 port=$2 timeout=${3:-60}
  local i=0
  while (( i < timeout )); do
    if (echo > /dev/tcp/$host/$port) 2>/dev/null; then return 0; fi
    sleep 1; i=$((i+1))
  done
  return 1
}

# --------------------------------------------------------------------------
# wait_for_udp_port — UE5 binds UDP; we can't simply connect.  Instead poll
# /proc/net/udp6 + /proc/net/udp for the bound port owned by our PID.
# --------------------------------------------------------------------------
wait_for_udp_bind() {
  local name=$1 port=$2 timeout=${3:-120}
  local hex_port; hex_port=$(printf '%04X' "$port")
  # NB: read_pid MUST live inside the loop. launch_bg writes the pidfile
  # from a backgrounded `setsid bash` and returns immediately, so when
  # the caller hits us right after launch_bg there is a real window
  # where the pidfile doesn't exist yet. Under fork contention (mock-k8s
  # warming 3 always-on maps in a tight burst) that window is hundreds
  # of ms long, longer than a few of our iterations. Capturing pid once
  # outside the loop sticks us at pid="" forever -> kill -0 "" always
  # fails -> we time out at 180s and start-ue5.sh dies, even though
  # UE5 has been bound + READY for minutes. mock-k8s then SIGTERMs the
  # perfectly healthy UE5; customers see "MX3 disconnect" ~3min after
  # spawn. Re-reading the pidfile each iteration closes the race.
  local i=0 pid=""
  while (( i < timeout )); do
    [ -z "$pid" ] && pid=$(read_pid "$name")
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null \
       && grep -qE ":$hex_port " /proc/net/udp /proc/net/udp6 2>/dev/null; then
      return 0
    fi
    sleep 1; i=$((i+1))
  done
  return 1
}

# --------------------------------------------------------------------------
# psql wrapper — runs as the current user, sets ICU_DATA + LD_LIBRARY_PATH
# --------------------------------------------------------------------------
PSQL_BIN="$EXTRACTED/postgres/usr/local/bin/psql"

pg_env() {
  echo "LD_LIBRARY_PATH=$(ldlib postgres) ICU_DATA=$(icu_dir postgres)"
}

psql_super() {
  env -i HOME=/tmp LC_ALL=C $(pg_env) \
    "$PSQL_BIN" -h "${PGHOST:-127.0.0.1}" -p "${PGPORT:-$DUNE_PG_PORT}" -U postgres -d "${1:-postgres}" -tA "${@:2}"
}

# --------------------------------------------------------------------------
# Resolve the AMP-provided IPs into well-named variables.  All scripts
# should reference these instead of DUNE_LAN_IP / DUNE_PUBLIC_IP directly.
#
# DUNE_BIND_IP   — what services bind to (AMP's $ApplicationIPBinding;
#                  127.0.0.1 for private services, container IP for public)
# DUNE_EXTERNAL_IP — what we advertise to FLS (AMP's $ExternalIP or user override)
# --------------------------------------------------------------------------
: "${DUNE_BIND_IP:=127.0.0.1}"
: "${DUNE_EXTERNAL_IP:=$DUNE_BIND_IP}"
export DUNE_BIND_IP DUNE_EXTERNAL_IP

# Per-instance internal ports (v19). Every service shares the host network
# namespace, so two Dune instances on one host collided on every fixed
# internal port (forum 43112: "could not bind to distribution port 25673").
# prestart.sh runs allocate_internal_ports on each start and persists the
# result here; every later stage picks it up by sourcing lib.sh.
if [ -f "$STATE/ports.env" ]; then
  # shellcheck disable=SC1091
  set -a; source "$STATE/ports.env"; set +a
fi

# Default port values. AMP-managed ports (game UDP pool, RMQ game AMQPS +
# HTTP) arrive via amp.env below; the rest come from ports.env.
: "${DUNE_PG_PORT:=15432}"
: "${DUNE_MQ_ADMIN_PORT:=5672}"
: "${DUNE_MQ_ADMIN_MGMT_PORT:=15672}"
: "${DUNE_MQ_GAME_PORT:=5673}"
: "${DUNE_MQ_GAME_MGMT_PORT:=15673}"
: "${DUNE_MQ_GAME_PROM_PORT:=15693}"
: "${DUNE_TEXT_ROUTER_PORT:=5059}"
: "${DUNE_DIRECTOR_PORT:=11717}"
: "${DUNE_GATEWAY_PORT:=8080}"
: "${DUNE_MQ_ADMIN_PROM_PORT:=15692}"
: "${DUNE_MQ_ADMIN_DIST_PORT:=25672}"
: "${DUNE_MQ_GAME_DIST_PORT:=25673}"
: "${DUNE_EPMD_PORT:=4369}"
: "${K8S_MOCK_PORT:=6443}"
: "${K8S_POOL_IGW_PORT_BASE:=7950}"
: "${K8S_POOL_SIZE:=25}"

export DUNE_PG_PORT DUNE_MQ_ADMIN_PORT DUNE_MQ_ADMIN_MGMT_PORT \
       DUNE_MQ_GAME_PORT DUNE_MQ_GAME_MGMT_PORT DUNE_MQ_GAME_PROM_PORT \
       DUNE_TEXT_ROUTER_PORT DUNE_DIRECTOR_PORT DUNE_GATEWAY_PORT \
       DUNE_MQ_ADMIN_PROM_PORT DUNE_MQ_ADMIN_DIST_PORT DUNE_MQ_GAME_DIST_PORT \
       DUNE_EPMD_PORT K8S_MOCK_PORT K8S_POOL_IGW_PORT_BASE K8S_POOL_SIZE

# --------------------------------------------------------------------------
# allocate_internal_ports — pick a free host port for each internal service
# and write $STATE/ports.env. Called by prestart.sh only, before any of our
# services run, so every listener seen in /proc/net belongs to someone else
# (another Dune instance, a host k3s on 6443, ...). For each port: keep the
# previously persisted value if still free (stable across restarts), else
# the default, else step up by 100 until free. The IGW pool needs a whole
# free block. Single-instance hosts keep the defaults.
# --------------------------------------------------------------------------
_dune_busy_ports() {
  # LISTEN tcp sockets (st 0A) and bound udp sockets (st 07), v4 + v6.
  # Pure bash: the image's awk isn't guaranteed to be gawk (no strtonum).
  local f sl loc rem st rest
  for f in /proc/net/tcp /proc/net/tcp6 /proc/net/udp /proc/net/udp6; do
    [ -r "$f" ] || continue
    while read -r sl loc rem st rest; do
      case "$f:$st" in
        */tcp*:0A|*/udp*:07) echo $((16#${loc##*:})) ;;
      esac
    done < <(tail -n +2 "$f")
  done | sort -un
}

allocate_internal_ports() {
  local busy taken="" out="" var def cur p i n ok size
  busy=" $(_dune_busy_ports | tr '\n' ' ') "
  # Ports AMP owns for this instance are free right now but will be ours.
  for p in "${DUNE_MQ_GAME_PORT:-}" "${DUNE_MQ_GAME_MGMT_PORT:-}"; do
    [ -n "$p" ] && taken="$taken $p "
  done
  _free() { case "$busy$taken" in *" $1 "*) return 1;; esac; [ "$1" -lt 65536 ]; }
  for spec in DUNE_PG_PORT:15432 DUNE_MQ_ADMIN_PORT:5672 DUNE_MQ_ADMIN_MGMT_PORT:15672 \
              DUNE_MQ_ADMIN_PROM_PORT:15692 DUNE_MQ_GAME_PROM_PORT:15693 \
              DUNE_MQ_ADMIN_DIST_PORT:25672 DUNE_MQ_GAME_DIST_PORT:25673 \
              DUNE_EPMD_PORT:4369 DUNE_TEXT_ROUTER_PORT:5059 DUNE_DIRECTOR_PORT:11717 \
              DUNE_GATEWAY_PORT:8080 K8S_MOCK_PORT:6443; do
    var=${spec%%:*}; def=${spec#*:}; cur=${!var:-$def}
    p=""
    for cand in "$cur" "$def"; do _free "$cand" && { p=$cand; break; }; done
    if [ -z "$p" ]; then
      for i in $(seq 1 50); do _free $((def + i*100)) && { p=$((def + i*100)); break; }; done
    fi
    [ -n "$p" ] || die "no free port found for $var (default $def)"
    [ "$p" != "$def" ] && log "  port $var: $def is in use on this host, using $p"
    taken="$taken $p "; out="$out$var=$p"$'\n'
    printf -v "$var" '%s' "$p"; export "$var"
  done
  size=${K8S_POOL_SIZE:-25}
  p=""
  for cand in "${K8S_POOL_IGW_PORT_BASE:-7950}" 7950 $(seq 8050 100 12950); do
    ok=1
    for ((n = cand; n < cand + size; n++)); do _free "$n" || { ok=0; break; }; done
    [ "$ok" = 1 ] && { p=$cand; break; }
  done
  [ -n "$p" ] || die "no free block of $size ports for the IGW pool"
  [ "$p" != 7950 ] && log "  port K8S_POOL_IGW_PORT_BASE: 7950-$((7950+size-1)) overlaps a port in use, using $p"
  out="${out}K8S_POOL_IGW_PORT_BASE=$p"$'\n'
  K8S_POOL_IGW_PORT_BASE=$p; export K8S_POOL_IGW_PORT_BASE
  printf '%s' "$out" > "$STATE/ports.env.tmp" && mv -f "$STATE/ports.env.tmp" "$STATE/ports.env"
  unset -f _free
}

# --------------------------------------------------------------------------
# AMP-supplied configuration — written by the "Render AMP env file"
# PreStartStage on every container start.  AMP doesn't propagate
# App.EnvironmentVariables to PreStartStages, so we materialise them
# via inline {{Var}} substitution into a file and source it here.
# --------------------------------------------------------------------------
if [ -z "${SKIP_AMPENV_SOURCE:-}" ] && [ -f "$RUNTIME/amp.env" ]; then
  # shellcheck disable=SC1091
  set -a; source "$RUNTIME/amp.env"; set +a
fi

# --------------------------------------------------------------------------
# Persisted state — each PreStartStage is a fresh bash invocation that
# doesn't inherit env exports from a sibling stage.  Anything prestart.sh
# derives (WorldName, RMQ secret) must be read from $STATE here so every
# subsequent stage picks it up automatically just by sourcing lib.sh.
# --------------------------------------------------------------------------
if [ -f "$STATE/world-name" ]; then
  DUNE_WORLD_NAME=$(cat "$STATE/world-name")
  export DUNE_WORLD_NAME
fi
if [ -f "$STATE/rmq-secret" ]; then
  DUNE_RMQ_SEC=$(cat "$STATE/rmq-secret")
  export DUNE_RMQ_SEC
fi
if [ -f "$STATE/svc-cmd-token" ]; then
  DUNE_SVC_CMD_TOKEN=$(cat "$STATE/svc-cmd-token")
  export DUNE_SVC_CMD_TOKEN
fi

# Mark lib loaded so children can sanity-check
export DUNE_LIB_LOADED=1
