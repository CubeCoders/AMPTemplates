#!/bin/bash
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# prestart.sh BASE_DIR
#
# Run by AMP as the first PreStartStage on every container start.
# Idempotent: safe to re-run.  Responsibilities:
#
#   1. Decode the JWT, derive/persist WorldName (FLS-registered identity)
#   2. Generate RMQ secret + self-signed TLS cert (replaces cert-manager)
#   3. Render runtime config files (rabbitmq.conf, director.ini, postgres.conf)
#   4. Ensure postgres data dir exists & is initdb'd (first run only)
#   5. Boot postgres briefly to load the schema via ToolsDB resetdb if missing
#   6. Seed dune.world_partition for the two stock maps
#
# Required env vars (set by AMP via App.EnvironmentVariables):
#   DUNE_JWT              — Funcom IGW JWT (Required:true on the template)
#   DUNE_WORLD_TITLE      — display name in server browser
#   DUNE_REGION           — "Europe Test" / "North America Test"
#   DUNE_BIND_IP          — what services bind to (AMP's $ApplicationIPBinding)
#   DUNE_EXTERNAL_IP      — advertised to FLS (AMP's $ExternalIP or override)
# Optional:
#   DUNE_WORLD_NAME_OVERRIDE — paste the Funcom-issued name to skip auto-gen

export SOURCE="prestart"
SKIP_AMPENV_SOURCE=1 source "$(dirname "$(readlink -f "$0")")/lib.sh" "$@"

# Wipe any leftover pid files from a previous incarnation BEFORE we
# launch anything new, so a stale value can't trick console.sh's
# shutdown_all into bashing on the wrong PID later.
purge_pids 2>/dev/null || rm -f "$RUNTIME/pids/"*.pid 2>/dev/null || true

# --------------------------------------------------------------------------
# Persist AMP-supplied env vars to runtime/amp.env so subsequent
# PreStartStages (start-pg.sh, start-*.sh, etc.) can source them via lib.sh.
# AMP doesn't propagate App.EnvironmentVariables to PreStartStages — the
# template invokes us with `bash -c "VAR=... VAR2=... prestart.sh BASE"` so
# the values arrive as our process env; we materialise them now.
# --------------------------------------------------------------------------
mkdir -p "$RUNTIME"

# Guard: required runtime setup is provisioned on container start and only
# takes effect from the next start. Fail fast if it is not present yet.
SA_DIR="/var/run/secrets/kubernetes.io/serviceaccount"
if [ ! -d "$SA_DIR" ] || [ ! -w "$SA_DIR" ]; then
  die "AMP instance must be restarted before it can be started."
fi

# Strip characters that would cause trouble in downstream shell contexts:
#   `   backtick — triggers command substitution inside "..." in start-*.sh
#       command-line args like  -ServerName="$DUNE_WORLD_TITLE"
#   |   pipe — wouldn't expand inside "..." but harmless to drop, and avoids
#       any future eval/heredoc path producing a pipeline
#   '   single-quote — survives AMP's '{{Var}}' substitution only because
#       AMP doesn't escape; drop it so we never produce a bash parse error
#       in any future env-passthrough that uses single-quotes
sanitise_shell_value() {
  local v="$1"
  v="${v//\`/}"
  v="${v//|/}"
  v="${v//\'/}"
  printf '%s' "$v"
}

{
  for v in DUNE_JWT DUNE_WORLD_TITLE DUNE_REGION DUNE_WORLD_NAME_OVERRIDE \
           DUNE_HOST_DC_ID DUNE_RELEASE_VERSION \
           DUNE_BIND_IP DUNE_EXTERNAL_IP \
           DUNE_MQ_GAME_PORT DUNE_MQ_GAME_MGMT_PORT \
           K8S_POOL_GAME_PORT_BASE; do
    raw="${!v:-}"
    clean=$(sanitise_shell_value "$raw")
    # %q produces shell-quoted output so values with spaces/specials round-trip
    printf '%s=%q\n' "$v" "$clean"
  done
} > "$RUNTIME/amp.env"
chmod 0600 "$RUNTIME/amp.env"

# Per-instance internal ports (see lib.sh) — before anything below renders
# a config file with a port in it.
allocate_internal_ports

# Derive the FLS environment from the selected build (ReleaseVersion):
# the PTC app id uses Funcom's beta FLS environment, production uses
# retail. Driven by the same setting that selects the Steam app id, so
# the FLS environment can never desync from the installed build.
case "${DUNE_RELEASE_VERSION:-}" in
  3104830) DUNE_FLS_ENV=beta ;;
  *)       DUNE_FLS_ENV=retail ;;
esac
printf 'DUNE_FLS_ENV=%q\n' "$DUNE_FLS_ENV" >> "$RUNTIME/amp.env"

log "Running pre-start setup..."
log "  Bind IP:      $DUNE_BIND_IP"
log "  External IP:  $DUNE_EXTERNAL_IP"
log "  World title:  ${DUNE_WORLD_TITLE:-<unset>}"
log "  Region:       ${DUNE_REGION:-<unset>}"

[ -n "${DUNE_JWT:-}" ] || die "Self-Host Service Token not set — paste your Funcom token into the AMP config"
[ -d "$EXTRACTED/postgres" ] || die "extracted prerequisites missing — run the Update step first"

# --------------------------------------------------------------------------
# 1. World identity
# --------------------------------------------------------------------------
log "Verifying world identity..."

# Decode JWT payload (base64url, no nested pipes — pipefail-safe)
PAYLOAD=$(awk -F. '{print $2}' <<< "$DUNE_JWT")
while [ $((${#PAYLOAD} % 4)) -ne 0 ]; do PAYLOAD="${PAYLOAD}="; done
PAYLOAD_STD=$(printf '%s' "$PAYLOAD" | tr '_-' '/+')
DECODED=$(printf '%s' "$PAYLOAD_STD" | base64 -d 2>/dev/null || true)
HOST_ID=$(printf '%s' "$DECODED" | jq -r '.HostId // empty' 2>/dev/null || true)
[ -n "$HOST_ID" ] || die "couldn't decode HostId from JWT — is the token valid?"
log "  HostId: $HOST_ID"

WN_FILE="$STATE/world-name"
FIRST_BIND=0
if [ -n "${DUNE_WORLD_NAME_OVERRIDE:-}" ]; then
  # Explicit override always wins. Use this to rebind to a previously
  # deployed BG name (e.g. after wiping state but wanting to keep FLS
  # identity) or to migrate from the legacy `-tczine` constant.
  printf '%s' "$DUNE_WORLD_NAME_OVERRIDE" > "$WN_FILE"
elif [ ! -f "$WN_FILE" ]; then
  # First install. Mirror Funcom's setup/world.sh:
  #     sh-<hostid>-<6 random lowercase letters>
  # The 6-letter suffix is arbitrary content-wise but must be unique per
  # battlegroup AND stable across boots — FLS keys characters/data by the
  # full WorldName, so changing the suffix after first registration looks
  # to FLS like a different battlegroup. We write the generated name to
  # state/world-name and never touch it again; the override above is the
  # only supported way to rebind.
  FIRST_BIND=1
  # 6 random lowercase letters. Pure bash, no pipeline: prestart.sh is
  # launched by AMP (a .NET process), and .NET sets SIGPIPE to SIG_IGN
  # process-wide; children inherit it. With SIGPIPE ignored the old
  # `tr -dc a-z </dev/urandom | fold | head` form span forever -- tr
  # was never killed when head closed the pipe. $RANDOM needs no pipe.
  _wn_alpha=abcdefghijklmnopqrstuvwxyz
  SUFFIX=
  for _ in 1 2 3 4 5 6; do SUFFIX+="${_wn_alpha:RANDOM%26:1}"; done
  WORLD_NAME="sh-$(echo "$HOST_ID" | tr 'A-Z' 'a-z')-$SUFFIX"
  echo "$WORLD_NAME" > "$WN_FILE"
fi
WORLD_NAME=$(cat "$WN_FILE")
export DUNE_WORLD_NAME="$WORLD_NAME"

if [ "$FIRST_BIND" = 1 ]; then
  log ""
  log "=========================================================================="
  log "FIRST-START FLS BINDING — RECORD THIS VALUE NOW"
  log ""
  log "  WorldName: $WORLD_NAME"
  log ""
  log "Funcom PERMANENTLY binds this name to your Self-Host Service Token on"
  log "first registration.  Save it somewhere durable (outside this server)."
  log "If you ever redeploy without a backup, paste it into the FLS World Name"
  log "(override) field in the AMP config to reclaim the same FLS slot."
  log "=========================================================================="
  log ""
else
  log "  WorldName: $WORLD_NAME"
fi

# RMQ HTTP-token auth secret
RMQ_SEC_FILE="$STATE/rmq-secret"
if [ ! -f "$RMQ_SEC_FILE" ]; then
  umask 077
  openssl rand -base64 64 | tr -d '\n' > "$RMQ_SEC_FILE"
fi
RMQ_SEC=$(cat "$RMQ_SEC_FILE")
export DUNE_RMQ_SEC="$RMQ_SEC"

# Server-commands auth token. The UE5 servers validate ServiceBroadcast
# / DuneServerCommands messages against this. FLS would normally supply
# it; for self-hosting we provision it ourselves so the module can issue
# server commands (announce). start-ue5.sh feeds it to the UE5 servers.
SVC_CMD_FILE="$STATE/svc-cmd-token"
if [ ! -f "$SVC_CMD_FILE" ]; then
  umask 077
  openssl rand -hex 16 | tr -d '\n' > "$SVC_CMD_FILE"
fi
export DUNE_SVC_CMD_TOKEN="$(cat "$SVC_CMD_FILE")"

# --------------------------------------------------------------------------
# 2. Self-signed RMQ TLS cert (replaces cert-manager from the k3s build)
# --------------------------------------------------------------------------
CERTDIR="$STATE/rmq-certs"
if [ ! -f "$CERTDIR/cert.pem" ] || [ ! -f "$CERTDIR/key.pem" ]; then
  log "Generating self-signed TLS certificate..."
  mkdir -p "$CERTDIR"
  openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
    -keyout "$CERTDIR/key.pem" -out "$CERTDIR/cert.pem" \
    -subj "/CN=$DUNE_EXTERNAL_IP" \
    -addext "subjectAltName=IP:$DUNE_EXTERNAL_IP,IP:$DUNE_BIND_IP,IP:127.0.0.1,DNS:localhost" 2>/dev/null
  cp "$CERTDIR/cert.pem" "$CERTDIR/cacert.pem"
  chmod 0644 "$CERTDIR"/*.pem
fi

# --------------------------------------------------------------------------
# 3. Render runtime config files
# --------------------------------------------------------------------------
log "Rendering runtime configuration..."

# RMQ system.conf files — envsubst expands $(VAR) inside.  We export the
# vars that the template references, then run envsubst.  Note: RabbitMQ
# itself ALSO does $(VAR) substitution at startup; we only do envsubst here
# for fields that should be baked rather than runtime-substituted.
mkdir -p "$RUNTIME/mq-admin" "$RUNTIME/mq-game"

# mq-admin: plain AMQP, auth backend = HTTP cache → text-router.
# All listeners bind to loopback only — mq-admin is purely internal.
cat > "$RUNTIME/mq-admin/rabbitmq.conf" <<EOF
auth_backends.1 = cache
auth_cache.cache_ttl = 5000
auth_cache.cached_backend = http
auth_http.http_method   = post
auth_http.user_path     = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/user
auth_http.vhost_path    = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/vhost
auth_http.resource_path = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/resource
auth_http.topic_path    = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/topic

# Internal-only HTTP listeners
management.tcp.ip   = 127.0.0.1
management.tcp.port = $DUNE_MQ_ADMIN_MGMT_PORT
prometheus.tcp.ip   = 127.0.0.1
prometheus.tcp.port = $DUNE_MQ_ADMIN_PROM_PORT
EOF

# mq-game: TLS AMQPS on the EXTERNALLY-REACHABLE bind IP
cat > "$RUNTIME/mq-game/rabbitmq.conf" <<EOF
auth_backends.1 = cache
auth_cache.cache_ttl = 5000
auth_cache.cached_backend = http
auth_http.http_method   = post
auth_http.user_path     = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/user
auth_http.vhost_path    = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/vhost
auth_http.resource_path = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/resource
auth_http.topic_path    = http://127.0.0.1:$DUNE_TEXT_ROUTER_PORT/v0/auth/topic

listeners.tcp = none
listeners.ssl.default = $DUNE_BIND_IP:$DUNE_MQ_GAME_PORT
ssl_options.cacertfile = $CERTDIR/cacert.pem
ssl_options.certfile   = $CERTDIR/cert.pem
ssl_options.keyfile    = $CERTDIR/key.pem
ssl_options.verify     = verify_none

management.tcp.ip   = $DUNE_BIND_IP
management.tcp.port = $DUNE_MQ_GAME_MGMT_PORT
prometheus.tcp.ip   = 127.0.0.1
prometheus.tcp.port = $DUNE_MQ_GAME_PROM_PORT
EOF

# postgres extension config (loaded via include_if_exists)
cat > "$RUNTIME/postgres.conf" <<EOF
idle_in_transaction_session_timeout = '60s'
shared_preload_libraries = 'pg_stat_statements'
pg_stat_statements.track = all
pg_stat_statements.max = 10000
track_activity_query_size = 2048
EOF

# director.ini — pulled from templates (k3s-extracted, then customised)
if [ -f "$TEMPLATES/director.ini" ]; then
  mkdir -p "$RUNTIME/director-conf.d"
  cp "$TEMPLATES/director.ini" "$RUNTIME/director-conf.d/director.ini"
fi

# --------------------------------------------------------------------------
# 4. Postgres data dir — initdb if first run
# --------------------------------------------------------------------------
PGDATA="$STATE/pg/data"
mkdir -p "$PGDATA"
chmod 0700 "$PGDATA"

if [ ! -f "$PGDATA/PG_VERSION" ]; then
  log "Initialising database (first run). This may take a minute without visible activity."
  env -i HOME=/tmp LC_ALL=C \
    LD_LIBRARY_PATH=$(ldlib postgres) \
    ICU_DATA=$(icu_dir postgres) \
    "$EXTRACTED/postgres/usr/local/bin/initdb" \
      -D "$PGDATA" -U postgres \
      --auth-host=scram-sha-256 --auth-local=trust \
      -E UTF8 --locale=C 2>&1 | tail -10

  # Append our overrides
  cat >> "$PGDATA/postgresql.conf" <<EOF
listen_addresses = '127.0.0.1'
port = $DUNE_PG_PORT
unix_socket_directories = '$RUNTIME/postgresql'
include_if_exists = '$RUNTIME/postgres.conf'
EOF

  cat > "$PGDATA/pg_hba.conf" <<'EOF'
local   all   all                trust
host    all   all   127.0.0.1/32 trust
host    all   all   ::1/128      trust
EOF
fi

# Port may change between starts (allocate_internal_ports); the include in
# postgresql.conf comes after its own "port =" line, so this wins.
printf 'port = %s\n' "$DUNE_PG_PORT" > "$RUNTIME/postgres.conf"

# --------------------------------------------------------------------------
# 5. Schema load — boot pg briefly via pg_ctl, run resetdb if schema missing,
# then stop pg cleanly so start-pg.sh can claim it.
# --------------------------------------------------------------------------
SCHEMA_MARKER="$STATE/schema-loaded"
if [ ! -f "$SCHEMA_MARKER" ]; then
  log "Loading database schema (first run). This may take several minutes without visible activity."
  PG_BIN="$EXTRACTED/postgres/usr/local/bin"
  PG_ENV="LD_LIBRARY_PATH=$(ldlib postgres) ICU_DATA=$(icu_dir postgres)"

  env -i HOME=/tmp LC_ALL=C $PG_ENV \
    "$PG_BIN/pg_ctl" -D "$PGDATA" -l "$LOGS/pg-init.log" -w -t 30 start \
    || { tail -20 "$LOGS/pg-init.log"; die "Postgres failed to start during schema load"; }

  # Trap to ensure we always stop pg even on failure below
  trap 'env -i HOME=/tmp LC_ALL=C '"$PG_ENV"' '"$PG_BIN"'/pg_ctl -D '"$PGDATA"' -w -t 30 stop -m fast >/dev/null 2>&1 || true' EXIT

  # Wait for ready
  for i in $(seq 1 30); do
    env -i HOME=/tmp LC_ALL=C $PG_ENV "$PG_BIN/pg_isready" -h 127.0.0.1 -p "$DUNE_PG_PORT" >/dev/null 2>&1 && break
    sleep 1
  done

  # resetdb expects the project user (`dune`) to already exist — it manages
  # databases but not roles.  Create it now if missing.
  USER_EXISTS=$(env -i HOME=/tmp LC_ALL=C $PG_ENV \
    "$PG_BIN/psql" -h 127.0.0.1 -p "$DUNE_PG_PORT" -U postgres -d postgres -tA \
    -c "SELECT 1 FROM pg_roles WHERE rolname='dune'" 2>/dev/null || true)
  if [ -z "$USER_EXISTS" ]; then
    log "  creating role 'dune'..."
    env -i HOME=/tmp LC_ALL=C $PG_ENV \
      "$PG_BIN/psql" -h 127.0.0.1 -p "$DUNE_PG_PORT" -U postgres -d postgres \
      -c "CREATE USER dune WITH PASSWORD 'dune' NOCREATEDB NOCREATEROLE" >/dev/null
  fi

  log "  invoking resetdb (loads schema via ToolsDB)..."
  ( cd "$EXTRACTED/db-utils/root/PSQL" && \
    LD_LIBRARY_PATH=$(ldlib db-utils) PYTHONPATH=. \
    "$EXTRACTED/db-utils/usr/local/bin/python3.12" resetdb.py \
      --local-as-remote --no-backup --unattended \
      --host 127.0.0.1:$DUNE_PG_PORT \
      --project-database dune --project-user dune --project-password dune \
      --admin-user postgres --admin-password '' \
      --schema-path "$EXTRACTED/game-server/home/dune/server/DuneSandbox/Database" \
      2>&1 | tail -20 ) || die "Database schema load failed — see output above"

  # Set default search_path so the world_partition trigger resolves the
  # unqualified procedure name it calls (dune.create_event_log_partition_table).
  env -i HOME=/tmp LC_ALL=C $PG_ENV \
    "$PG_BIN/psql" -h 127.0.0.1 -p "$DUNE_PG_PORT" -U postgres -d dune <<'SQL' >/dev/null
ALTER DATABASE dune SET search_path TO dune,public;
ALTER ROLE dune SET search_path TO dune,public;
SQL

  touch "$SCHEMA_MARKER"
  log "Database schema loaded: success."
fi

# --------------------------------------------------------------------------
# 6. Make sure pg is up for the remaining prestart steps.
# --------------------------------------------------------------------------
PG_RUN_ENV="LD_LIBRARY_PATH=$(ldlib postgres) ICU_DATA=$(icu_dir postgres)"
PG_BIN="$EXTRACTED/postgres/usr/local/bin"

# Ensure pg is up (in case schema was already loaded on a previous run and
# we skipped that block).
env -i HOME=/tmp LC_ALL=C $PG_RUN_ENV \
  "$PG_BIN/pg_isready" -h 127.0.0.1 -p "$DUNE_PG_PORT" >/dev/null 2>&1 || \
  env -i HOME=/tmp LC_ALL=C $PG_RUN_ENV \
    "$PG_BIN/pg_ctl" -D "$PGDATA" -l "$LOGS/pg-init.log" -w -t 30 start >/dev/null 2>&1 || true

# (v19) The hardcoded 28-row world_partition seed that lived here is gone:
# mock-k8s syncs world_partition from Funcom's world-template.yaml on every
# start (partitions.go), so maps added by a game update just work.

# --------------------------------------------------------------------------
# 7. Stop pg if we started it — start-pg.sh will bring it up as the real
# long-lived background process.
# --------------------------------------------------------------------------
env -i HOME=/tmp LC_ALL=C \
  LD_LIBRARY_PATH=$(ldlib postgres) ICU_DATA=$(icu_dir postgres) \
  "$EXTRACTED/postgres/usr/local/bin/pg_ctl" -D "$PGDATA" -w -t 30 stop -m fast \
  >/dev/null 2>&1 || true
trap - EXIT

# --------------------------------------------------------------------------
# 8. UE5 saved dir — symlink into the extracted game-server tree so the
# binary writes persistent data into $STATE/ue5-saved/ instead of the
# read-only(ish) extraction.
# --------------------------------------------------------------------------
mkdir -p "$STATE/ue5-saved"
SAVED_TARGET="$EXTRACTED/game-server/home/dune/server/DuneSandbox/Saved"
mkdir -p "$(dirname "$SAVED_TARGET")"
rm -rf "$SAVED_TARGET"
ln -sfn "$STATE/ue5-saved" "$SAVED_TARGET"

# --------------------------------------------------------------------------
# 8a. Admin-editable config files
#
# Funcom ships two user-editable INI templates in the depot at
# scripts/setup/config/ — UE5 reads them from DuneSandbox/Saved/UserSettings/.
# We seed those on first run, then expose them at the instance root via
# symlinks so the AMP file browser shows them next to README etc., matching
# the layout in Funcom's official documentation.
#
# Same treatment for director_config.ini — Funcom's authoritative
# director config (per-map player caps, transfer rules, instancing modes,
# world-closure flags).
# --------------------------------------------------------------------------
USERSETTINGS="$STATE/ue5-saved/UserSettings"
mkdir -p "$USERSETTINGS"

for f in UserEngine.ini UserGame.ini UserServerCustomSettings.ini; do
  if [ ! -f "$USERSETTINGS/$f" ] && [ -f "$DEPOT/scripts/setup/config/$f" ]; then
    cp "$DEPOT/scripts/setup/config/$f" "$USERSETTINGS/$f"
    log "  seeded admin file: UserSettings/$f"
  fi
done

# DUNE-CUSTOMSETTINGS-SNAPSHOT (v19) - a UE5 server that boots without a
# UserServerCustomSettings.ini writes a full snapshot of built-in defaults
# to Saved/Config/LinuxServer/ServerCustomSettings.ini. That generated
# layer outranks UserSettings/, and our Saved/ is persistent (Funcom's
# pods are not), so the snapshot masked every later admin edit (forum
# 43144/43145). With the user file seeded above none is written; set
# aside any left from earlier boots. start-ue5.sh repeats this per launch.
_cs_snap="$STATE/ue5-saved/Config/LinuxServer/ServerCustomSettings.ini"
if [ -f "$_cs_snap" ] && [ -f "$USERSETTINGS/UserServerCustomSettings.ini" ]; then
  mv -f "$_cs_snap" "$STATE/ue5-saved/ServerCustomSettings.defaults-snapshot.bak"
  log "  set aside stale ServerCustomSettings.ini defaults snapshot (UserServerCustomSettings.ini now applies)"
fi
unset _cs_snap

DIR_TPL="$EXTRACTED/director/Tools/Battlegroups/Director/BattlegroupDirector/director_config.ini"
DIR_PRISTINE="$STATE/.director_config.ini.shipped"
# DUNE-DIRECTOR-CONFIG-DRIFT (v19) - the admin copy is seeded once, so a
# pre-1.5 install kept a director_config.ini without InstancingModes for
# the maps 1.5 added and director rejected them. Whenever Funcom ships a
# different file, merge it in while keeping the admin's own edits.
if [ -f "$STATE/director_config.ini" ] && [ -f "$DIR_TPL" ] && \
   ! cmp -s "$DIR_TPL" "$DIR_PRISTINE" 2>/dev/null; then
  cp -p "$STATE/director_config.ini" "$STATE/director_config.ini.bak-$(date +%Y%m%d%H%M%S)"
  if msg=$(LD_LIBRARY_PATH=$(ldlib db-utils) "$EXTRACTED/db-utils/usr/local/bin/python3.12" \
             "$SCRIPTS/ini-merge.py" "$DIR_TPL" "$STATE/director_config.ini" "$DIR_PRISTINE" 2>&1); then
    log "  director_config.ini: $msg"
  else
    warn "director_config.ini merge failed (keeping admin copy as-is): $msg"
  fi
fi
if [ ! -f "$STATE/director_config.ini" ]; then
  if [ -f "$DIR_TPL" ]; then
    cp "$DIR_TPL" "$STATE/director_config.ini"
    cp "$DIR_TPL" "$DIR_PRISTINE"
    # Funcom ships level=debug; default to info to cut log spam. Admins
    # can still edit this file afterwards (we only seed when absent).
    sed -i 's/^level=debug\b/level=info/' "$STATE/director_config.ini"
    log "  seeded admin file: director_config.ini (logging: info)"
  fi
fi

# AMP's metaconfig automap now targets the real state files directly
# ($STATE/ue5-saved/UserSettings/*.ini, $STATE/ondemand.ini — see
# metaconfig.json). We deliberately do NOT symlink them into server/:
# AMP merges config with an atomic temp+rename that turns a symlink into
# a regular file, and this script (running AFTER AMP's merge) would then
# clobber that write by recreating the link. Pointing AMP straight at the
# state files removes the race entirely.
BASEDIR="$BASE/server"
for stale in UserEngine.ini UserGame.ini director_config.ini; do
  [ -L "$BASEDIR/$stale" ] && rm -f "$BASEDIR/$stale"
done

# Seed ondemand.ini so AMP's automap has a file to merge into (AMP logged
# "file does not exist" otherwise). Defaults mirror mock-k8s's built-ins.
if [ ! -f "$STATE/ondemand.ini" ]; then
  cat > "$STATE/ondemand.ini" <<'ONDEMAND_SEED'
; On-Demand Instancing - consumed by mock-k8s for the dynamic server pool.
MaxConcurrentInstances=8
AutomaticStopDuration=10m
AlwaysWarmMaps=Survival_1,Overmap,DeepDesert_1
ONDEMAND_SEED
  log "  seeded admin file: ondemand.ini"
fi

# Make a fresh copy of director_config.ini into the runtime conf dir on
# every start, so director picks up any admin edits.  Named both ways
# because we're not 100% sure which the .NET binary expects.
mkdir -p "$RUNTIME/director-conf.d"
cp -f "$STATE/director_config.ini" "$RUNTIME/director-conf.d/director_config.ini" 2>/dev/null || true
cp -f "$STATE/director_config.ini" "$RUNTIME/director-conf.d/director.ini"        2>/dev/null || true

# DUNE-FUNCOM-MISSING-MAPS - Funcom ships director.ini without complete
# config for a few extra/DLC maps (CB_Overland_S_08, CB_Dungeon_ThePit).
# (v19 dropped CB_SurvivalChallenge_Station_15: director >= 1.5 no longer
# knows it, and its partition id collided with Funcom's.) Director rejects travel with
# "Found unrecognized map: <name>" unless BOTH are present:
#   1. A [ <map> ] section (so director loads its per-map config)
#   2. A <map>=ClassicalInstancing line under [ InstancingModes ] (so
#      director knows how to allocate it)
# Both injects idempotent. CR-tolerant: Funcom's director.ini is CRLF, so
# new lines also end with \r to keep the file consistent.
#
# (v5 temporarily removed Station_15 here on the mistaken theory that it
# caused the MX3 disconnect; v6 restored it after the actual cause was
# fixed in lib.sh:wait_for_udp_bind.)
_dune_inject_missing_map() {
  local f=$1 map=$2 mode=$3
  [ -f "$f" ] || return 0
  # 1. per-map section
  if ! grep -q "^\[ ${map} \]" "$f"; then
    printf '\n[ %s ]\r\nNumExtraServers = 0\r\n' "$map" >> "$f"
    log "  director.ini: injected missing map section [ $map ] ($(basename "$f"))"
  fi
  # 2. InstancingModes entry — must go INSIDE the [ InstancingModes ]
  #    section, not at EOF. Use awk: when we see the InstancingModes
  #    header, print existing lines until the NEXT [ ... ] section
  #    header, inserting our line just before that.
  if ! grep -qE "^${map}=" "$f"; then
    awk -v map="$map" -v mode="$mode" '
      BEGIN{im=0; inserted=0}
      /^\[ InstancingModes \]/ {print; im=1; next}
      im==1 && /^\[/ && inserted==0 {printf "%s=%s\r\n", map, mode; inserted=1; im=0}
      {print}
      END {if (im==1 && inserted==0) printf "%s=%s\r\n", map, mode}
    ' "$f" > "$f.tmp" && mv "$f.tmp" "$f" && chown amp:amp "$f" 2>/dev/null
    log "  director.ini: injected InstancingMode $map=$mode ($(basename "$f"))"
  fi
}
for _f in "$RUNTIME/director-conf.d/director.ini" "$RUNTIME/director-conf.d/director_config.ini"; do
  _dune_inject_missing_map "$_f" CB_Overland_S_08                ClassicalInstancing
  _dune_inject_missing_map "$_f" CB_Dungeon_ThePit               ClassicalInstancing
done
unset _f

# DUNE-FUNCOM-DLC-AUTOSCALE - DLC Lost Harvest maps (and any other map
# Funcom marks with EnableAutomaticInstanceScaling=false) won't scale
# on self-host. On retail Funcom uses a separate controller to scale
# them; we don't have one, so director's travel-queue processor logs
# "servers: [], num: 0" forever and players sit in PROVISIONING.
# Flip the flag to true so the normal scale path takes over.
# Idempotent. Safe to remove if Funcom ever changes the default.
for _f in "$RUNTIME/director-conf.d/director.ini" "$RUNTIME/director-conf.d/director_config.ini"; do
  if [ -f "$_f" ] && grep -q '^EnableAutomaticInstanceScaling=false' "$_f"; then
    # NB: no $ anchor — director.ini is CRLF, so the line ends
    # 'false\r'; anchoring on $ would never match the \r-suffixed value.
    sed -i 's/^EnableAutomaticInstanceScaling=false/EnableAutomaticInstanceScaling=true/g' "$_f"
    log "  director.ini: enabled instance scaling on DLC maps ($(basename "$_f"))"
  fi
done
unset _f


# --------------------------------------------------------------------------
# --------------------------------------------------------------------------
# Merge UserOverrides.ini into UserGame.ini.
#
# DefaultGame.ini exposes hundreds of [/Script/DuneSandbox.*] tuning keys;
# only a handful are practical to surface in AMP's settings UI. The rest
# are admin-editable as raw INI in state/UserOverrides.ini, which we append
# verbatim to the end of UserGame.ini here - after AMP's automap merge has
# run - so the overrides take precedence and survive AMP rewriting the file.
# Marker comments delimit the appended block: we strip any prior copy and
# re-append, so editing UserOverrides.ini just needs a restart to apply.
# --------------------------------------------------------------------------
STATE_UG="$STATE/ue5-saved/UserSettings/UserGame.ini"
OVERRIDES_INI="$STATE/UserOverrides.ini"
OVR_BEGIN="; >>>>> AMP: UserOverrides.ini appended below - do not edit past this line >>>>>"
OVR_END="; <<<<< AMP: end of UserOverrides.ini <<<<<"

if [ ! -f "$OVERRIDES_INI" ]; then
  cat > "$OVERRIDES_INI" <<'OVR_TEMPLATE'
; ============================================================================
; UserOverrides.ini  -  advanced dedicated-server gameplay overrides
;
; Everything in this file is appended verbatim to UserGame.ini on every
; server start, after AMP has written its managed settings. Use it for the
; large set of [/Script/DuneSandbox.*] tuning keys that are not surfaced in
; the AMP settings UI.
;
; The full list of available sections, keys and default values is in the
; game's own DuneSandbox/Config/DefaultGame.ini. Copy in only what you want
; to change, for example:
;
;   [/Script/DuneSandbox.SandwormSettings]
;   SomeKey=SomeValue
;
; Keys here take precedence over AMP-managed values. Changes apply on the
; next server restart.
; ============================================================================
OVR_TEMPLATE
  log "  seeded admin file: UserOverrides.ini"
fi

if [ -f "$STATE_UG" ]; then
  # Strip any previously-appended block (BEGIN..END inclusive).
  if grep -qF "$OVR_BEGIN" "$STATE_UG"; then
    awk -v b="$OVR_BEGIN" -v e="$OVR_END" \
      '$0==b{skip=1} !skip{print} skip&&$0==e{skip=0}' \
      "$STATE_UG" > "$STATE_UG.tmp" && mv "$STATE_UG.tmp" "$STATE_UG"
  fi
  # Re-append a fresh copy.
  {
    printf '%s\n' "$OVR_BEGIN"
    cat "$OVERRIDES_INI"
    printf '%s\n' "$OVR_END"
  } >> "$STATE_UG"
  log "  merged UserOverrides.ini into UserGame.ini"
fi

log "Pre-start setup: success."
