#!/bin/bash
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# console.sh BASE_DIR
#
# Foreground "console" process AMP attaches to.  Multiplexes all service
# logs into one stdout stream with [service] prefixes, and on SIGTERM
# stops each background service in reverse dependency order.
#
# AMP's lifecycle:
#   - AMP runs all PreStartStages (start-pg, start-mq-*, etc.) which leave
#     services running in the background with PID files in $RUNTIME/pids/
#   - AMP then runs App.ExecutableLinux which is this script
#   - AMP attaches its console to our stdout
#   - On stop, AMP sends SIGTERM per App.ExitMethod=SIGTERM
#   - We trap, send SIGTERM to each service PID in reverse order, wait, exit

BASE="${1:-${DUNE_BASE_DIR:-}}"
export SOURCE="amp"
source "$(dirname "$(readlink -f "$0")")/lib.sh" "$BASE"
source "$(dirname "$(readlink -f "$0")")/dune-commands.sh"

# Dependency order — services started in this order; stopped in reverse
SERVICES=(postgres mq-admin mq-game text-router mock-k8s director gateway ue5-Survival_1 ue5-Overmap ue5-DeepDesert_1)

# --------------------------------------------------------------------------
# Shutdown handler
# --------------------------------------------------------------------------
# _dune_sweep KEEP_PID — force a clean container: SIGKILL every process
# except tini (pid 1), AMP, and KEEP_PID. Matches AMP/tini by the short
# process name in /proc/PID/comm (newline-terminated, no delimiter games).
# This is the deterministic backstop: it does not care how RabbitMQ/Erlang
# or our log tails fragment across process groups.
_dune_sweep() {
  local _keep=$1 _p _c
  for _p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    case "$_p" in 1|"$_keep") continue;; esac
    _c=$(cat "/proc/$_p/comm" 2>/dev/null)
    case "$_c" in AMP_Linux_x86*|tini) continue;; esac
    kill -KILL "$_p" 2>/dev/null || true
  done
}

# _sweep KEEP_PID AMP_PID — aggressive mop-up. SIGKILL every process except
# tini (pid 1), AMP, and KEEP_PID. Excludes PURELY by pid: it never reads
# /proc/PID/* because a read against a process in uninterruptible-D state (a
# game server mid-save) can block the shell indefinitely, whereas kill never
# blocks. Nothing but AMP runs in this container, so being this blunt is safe.
# Refuses to run with an implausible AMP pid so it can never kill AMP itself.
_sweep() {
  local _keep=$1 _amp=$2 _p
  if [ -z "$_amp" ] || ! [ "$_amp" -gt 1 ] 2>/dev/null; then
    log "  sweep ABORTED: implausible amp pid '$_amp'"
    return
  fi
  for _p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    case "$_p" in 1|"$_keep"|"$_amp") continue;; esac
    kill -KILL "$_p" 2>/dev/null || true
  done
}

shutdown_all() {
  # A second stop signal must not re-enter and derail the teardown.
  # SIGALRM included: the main loop's pending `read -t 5` arms a SIGALRM
  # timer; while this trap handler runs that stale alarm fires ~5s in and
  # longjmps bash back to the read loop, abandoning the teardown (exit 142
  # in the trace). Ignoring it lets the handler finish. Our waits use
  # sleep/nanosleep, not SIGALRM, so this is safe.
  trap '' SIGTERM SIGINT SIGHUP SIGALRM
  [ -n "${_DUNE_SHUTTING_DOWN:-}" ] && return
  _DUNE_SHUTTING_DOWN=1

  # Send output to a file, never AMP's console pipe, so a closed pipe cannot
  # EPIPE-abort us mid-teardown.
  exec >>"$LOGS/shutdown.log" 2>&1
  trap "" PIPE


  local _main=$$ _amp=$PPID
  printf '\n===== %s shutdown_all main=%s amp=%s =====\n' "$(date -u +%FT%TZ)" "$_main" "$_amp"

  # Failsafe: if the ordered teardown ever wedges, mop up and kill this shell
  # at 75s (inside AMP ExitTimeout=120) so AMP always gets a clean stop. In
  # the normal path the final sweep below kills this timer first.
  ( sleep 75; _sweep "$_main" "$_amp"; kill -KILL "$_main" 2>/dev/null ) &
  disown

  # SIGTERM a service's whole process group from its pidfile. Reads only the
  # pidfile (a regular file, never blocks); no /proc reads, no liveness polls.
  _term() {
    local p; p=$(cat "$RUNTIME/pids/$1.pid" 2>/dev/null)
    case "$p" in ''|*[!0-9]*) return;; esac
    log "  SIGTERM $1 pgid $p"
    kill -TERM -- -"$p" 2>/dev/null || true
  }

  # 1. Director first: stop it issuing scale/travel instructions.
  log "1/5 director"
  _term director
  sleep 3

  # 2. Gateway + text-router (rest of the FLS/.NET bridge; they use RMQ so
  #    they go before the brokers).
  log "2/5 gateway + text-router"
  _term gateway
  _term text-router
  sleep 2

  # 3. RabbitMQ brokers.
  log "3/5 rabbitmq brokers"
  _term mq-game
  _term mq-admin
  sleep 3

  # 4. mock-k8s owns the UE5 servers: its SIGTERM handler drains them. We also
  #    SIGTERM the UE5 groups directly as insurance against a slow/hung
  #    orchestrator. Postgres is still up so the saves land.
  log "4/5 mock-k8s drains UE5 + direct UE5 SIGTERM, 20s save window"
  _term mock-k8s
  _term ue5-Survival_1
  _term ue5-Overmap
  _term ue5-DeepDesert_1
  sleep 20

  # 5. Postgres, after the saves.
  log "5/5 postgres"
  _term postgres
  sleep 5

  # 6. Aggressive mop-up: anything still alive (RabbitMQ's multi-pgid helper
  #    swarm, a hung mock-k8s, orphaned log tails) is force-killed. Non-blocking.
  log "final sweep"
  _sweep "$_main" "$_amp"
  log "Shutdown complete: success"
  exec true
}
# Stop signals set a flag only. Running the teardown straight from a
# trap is the bug we chased for days: a trap firing during `read -t 5`
# leaves that read's SIGALRM armed, and bash's internal read-timeout
# longjmp (NOT suppressible via trap) fires ~5s in and abandons the
# teardown (exit 142). The main loop runs shutdown_all after read
# returns, where no alarm is armed.
_DUNE_STOP=0
trap '_DUNE_STOP=1' SIGTERM SIGINT SIGHUP

# --------------------------------------------------------------------------
# Verify everyone started OK (PID files exist and processes alive)
# --------------------------------------------------------------------------
log "Verifying service status..."
all_ok=1
for svc in "${SERVICES[@]}"; do
  pid=$(read_pid "$svc")
  if [ -z "$pid" ]; then
    warn "  $svc: no PID file — service did not start"
    all_ok=0
  elif ! kill -0 "$pid" 2>/dev/null; then
    warn "  $svc: pid $pid not running"
    all_ok=0
  else
    log "  $svc: pid $pid OK"
  fi
done
[ "$all_ok" = 1 ] || warn "One or more services failed to start — see logs above"

# --------------------------------------------------------------------------
# Print a single ready marker that AMP's AppReadyRegex can hook
# --------------------------------------------------------------------------
log "Dune Awakening server ready: success"
log "  World name:   ${DUNE_WORLD_NAME:-?}"
log "  Title:        ${DUNE_WORLD_TITLE:-?}"
log "  External IP:  ${DUNE_EXTERNAL_IP:-?}"
log "  Region:       ${DUNE_REGION:-?}"

# --------------------------------------------------------------------------
# Tail every service log, prefixed with [service]
# --------------------------------------------------------------------------
LOG_FILES=()
for svc in "${SERVICES[@]}"; do
  f="$LOGS/$svc.log"
  touch "$f"
  LOG_FILES+=("$f")
done

# We want one combined stream prefixed with [service].  Use one background
# tail per file with awk-prefix, all piped into our stdout.
(
  for svc in "${SERVICES[@]}"; do
    f="$LOGS/$svc.log"
    tail -n 0 -F "$f" 2>/dev/null | gawk -v svc="$svc" '
      function classify(line,    m) {
        # Our own services emit "[LEVEL] message" — promote directly.
        if (match(line, /\[(DEBUG|INFO|WARN|ERROR)\]/, m)) return m[1]
        # Director emits e.g. "[16:34:56 27 DBG IGWO] message".
        if (match(line, /\[[0-9:]+ +[0-9]+ +(DBG|INF|WRN|ERR) /, m)) {
          if (m[1] == "DBG") return "DEBUG"
          if (m[1] == "INF") return "INFO"
          if (m[1] == "WRN") return "WARN"
          if (m[1] == "ERR") return "ERROR"
        }
        # Fallback: keyword scan (legacy behaviour).
        l = tolower(line)
        if (l ~ /\<(error|fatal|failed|exception|critical|crash)\>/) return "ERROR"
        if (l ~ /\<(warn|warning)\>/) return "WARN"
        return "INFO"
      }
      {
        type = classify($0)
        printf "[%s] [%s] %s\n", svc, type, $0
        fflush()
      }' &
  done
  wait
) &
TAIL_PID=$!

# --------------------------------------------------------------------------
# Watch-and-block: if every backend process dies, exit so AMP restarts us
# --------------------------------------------------------------------------
while true; do
  # Teardown runs HERE (not in the signal trap) so no armed read -t
  # alarm can longjmp out of it mid-stop. See the trap note above.
  [ "${_DUNE_STOP:-0}" = 1 ] && shutdown_all
  any_alive=0
  for svc in "${SERVICES[@]}"; do
    pid=$(read_pid "$svc")
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && any_alive=1
  done
  if [ "$any_alive" = 0 ]; then
    warn "All services have exited: failed — bailing out so AMP can restart"
    [ -n "${TAIL_PID:-}" ] && kill "$TAIL_PID" 2>/dev/null || true
    exit 1
  fi
  # Log-size watchdog. Any Funcom binary (esp. the director) can grow its
  # log without bound and fill the disk, which breaks Postgres writes and
  # stalls this very shutdown path. Every ~60 ticks (~5 min) copytruncate
  # any service log over the cap down to its last 32 MB. Safe against the
  # live writer: launch_bg opens logs O_APPEND so each write re-seeks to
  # EOF; truncating in place cannot leave a sparse hole. Override the cap
  # with DUNE_LOG_CAP_BYTES.
  _logwd=$(( ${_logwd:-0} + 1 ))
  if (( _logwd >= 60 )); then
    _logwd=0
    _cap=${DUNE_LOG_CAP_BYTES:-268435456}
    for _lf in "$LOGS"/*.log; do
      [ -f "$_lf" ] || continue
      _sz=$(stat -c %s "$_lf" 2>/dev/null || echo 0)
      if (( _sz > _cap )); then
        if tail -c 33554432 "$_lf" > "$_lf.wd" 2>/dev/null; then
          : > "$_lf"; cat "$_lf.wd" >> "$_lf"; rm -f "$_lf.wd"
          warn "log watchdog: truncated $(basename "$_lf") (was $_sz bytes, cap $_cap)"
        fi
      fi
    done
    # The director's Serilog rolling-file sink writes daily files to its
    # own logs dir with no retention cap (separate from the stdout log
    # above). Prune dated rolls older than 3 days; today's active file
    # keeps a current mtime so -mtime +3 never matches it.
    _dirlogs="$EXTRACTED/director/Tools/Battlegroups/Director/BattlegroupDirector/logs"
    [ -d "$_dirlogs" ] && find "$_dirlogs" -type f -name "director20*.log" -mtime +3 -delete 2>/dev/null
  fi
  # Read one console command from stdin (the AMP console). The 5s timeout
  # doubles as the service-watchdog tick; SIGTERM interrupts read promptly.
  if IFS= read -r -t 5 _cmdline; then
    _cmdline=${_cmdline%$'
'}
    if [ -n "$_cmdline" ]; then
      # re-source so command tweaks apply without an instance restart
      source "$(dirname "$(readlink -f "$0")")/dune-commands.sh" 2>/dev/null
      dune_dispatch "$_cmdline"
    fi
  else
    [ $? -le 128 ] && sleep 5   # EOF (no console attached) - avoid busy-loop
  fi
done
