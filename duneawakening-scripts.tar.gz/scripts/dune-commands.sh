#!/bin/bash
# © 2026 CubeCoders Limited. All Rights Reserved.
#
# dune-commands.sh — console command handlers for the Dune Awakening module.
# console.sh re-sources this on every console line, then calls dune_dispatch.
#
# Add a command: write dune_cmd_<name> and a dune_dispatch case.
# Requires lib.sh already sourced (rootfs, ldlib_mq, RUNTIME, DUNE_*).

# rabbitmqctl against the game broker (erlang-cookie auth — no AMQP creds).
_dune_rmqctl() {
  local mq erts
  mq=$(rootfs mq)
  erts=$(echo "$mq"/opt/erlang/lib/erlang/erts-*/bin)
  env -i HOME="$RUNTIME/mq-game-home" LC_ALL=C \
    LD_LIBRARY_PATH="$(ldlib_mq)" \
    ERL_EPMD_ADDRESS=127.0.0.1 \
    ERL_EPMD_PORT="${DUNE_EPMD_PORT:-4369}" \
    ERL_ROOTDIR="$mq/opt/erlang/lib/erlang" \
    PATH="$mq/opt/rabbitmq/sbin:$mq/opt/erlang/lib/erlang/bin:$erts:$mq/opt/erlang/bin:/usr/bin:/bin" \
    "$mq/opt/rabbitmq/sbin/rabbitmqctl" -n rabbit-game@localhost "$@"
}

# announce <title> | <message> [| <seconds>] — ServiceBroadcast title-card
# popup shown to every connected player. Default visible duration 30s.
dune_cmd_announce() {
  local arg="$*"
  if [ -z "$arg" ]; then
    echo "[command] usage: announce <title> | <message> [| <seconds>]"
    return 1
  fi
  if [ -z "${DUNE_SVC_CMD_TOKEN:-}" ]; then
    echo "[command] announce unavailable: ServerCommands token not provisioned"
    return 1
  fi
  local title body dur=30 rest
  case "$arg" in
    *" | "*" | "*)
      title="${arg%% | *}"; rest="${arg#* | }"
      body="${rest% | *}"; dur="${rest##* | }" ;;
    *" | "*)
      title="${arg%% | *}"; body="${arg#* | }" ;;
    *)
      title="Server Announcement"; body="$arg" ;;
  esac
  case "$dur" in ''|*[!0-9]*) dur=30 ;; esac
  local tb bb erl res
  tb=$(printf '%s' "$title" | base64 -w0 | tr -d '\n')
  bb=$(printf '%s' "$body"  | base64 -w0 | tr -d '\n')
  erl=$(cat <<'DUNE_ERL'
Title = base64:decode(<<"__TB__">>),
Body  = base64:decode(<<"__BB__">>),
EnE = #{<<"Key">> => <<"en">>,    <<"Title">> => Title, <<"Body">> => Body},
EnU = #{<<"Key">> => <<"en-US">>, <<"Title">> => Title, <<"Body">> => Body},
Inner = iolist_to_binary(rabbit_json:encode(#{
  <<"ServerCommand">> => <<"ServiceBroadcast">>,
  <<"BroadcastType">> => <<"Generic">>,
  <<"BroadcastPayload">> => #{<<"BroadcastDuration">> => __DUR__,
                              <<"LocalizedText">> => [EnE, EnU]}})),
Outer = iolist_to_binary(rabbit_json:encode(#{
  <<"Version">> => 2, <<"AuthToken">> => <<"__TOKEN__">>,
  <<"MessageContent">> => Inner})),
XName = rabbit_misc:r(<<"/">>, exchange, <<"heartbeats">>),
X = rabbit_exchange:lookup_or_die(XName),
MsgId = list_to_binary("cc-announce-" ++ integer_to_list(erlang:system_time(millisecond))),
P = {list_to_atom("P_basic"), <<"Content">>, undefined, [], undefined,
     undefined, undefined, undefined, undefined, MsgId, undefined,
     undefined, <<"fls">>, <<"fls_backend">>, undefined},
{ok, Msg} = rabbit_basic:message(XName, <<"notifications">>,
                                 rabbit_basic:build_content(P, Outer)),
io:format("~p~n", [rabbit_queue_type:publish_at_most_once(X, Msg)]).
DUNE_ERL
)
  erl=${erl//__TB__/$tb}
  erl=${erl//__BB__/$bb}
  erl=${erl//__TOKEN__/$DUNE_SVC_CMD_TOKEN}
  erl=${erl//__DUR__/$dur}
  res=$(_dune_rmqctl eval "$erl" 2>/dev/null | head -1 | tr -d '[:space:]')
  echo "[command] announce ($res, ${dur}s): [$title] $body"
}


# players — list connected players (chat.proximity bindings whose queue has
# a live consumer).
dune_cmd_players() {
  local erl out
  erl='PX = {resource,<<"/">>,exchange,<<"chat.proximity">>},
Bs = (catch rabbit_binding:list_for_source(PX)),
On = case is_list(Bs) of
  true -> lists:filtermap(fun(Bd) ->
       Dst = element(4, Bd),
       case rabbit_amqqueue:lookup(Dst) of
         {ok, Q} -> case rabbit_amqqueue:info(Q, [consumers]) of
                      [{consumers, C}] when C > 0 -> {true, element(3, Bd)};
                      _ -> false end;
         _ -> false
       end end, Bs);
  _ -> [] end,
U = lists:usort(On),
io:format("~p|~ts~n", [length(U), iolist_to_binary(lists:join(<<", ">>, U))]).'
  out=$(_dune_rmqctl eval "$erl" 2>/dev/null | head -1)
  local cnt="${out%%|*}" names="${out#*|}"
  case "$cnt" in
    ''|*[!0-9]*) echo "[command] players: query failed" ;;
    0)           echo "[command] players online: 0" ;;
    *)           echo "[command] players online: $cnt — $names" ;;
  esac
}

# status — map-server and player-count summary.
dune_cmd_status() {
  local erl out
  erl='SrvN = lists:foldl(fun(Q,A) ->
  Nm = element(4,element(2,Q)),
  C = case rabbit_amqqueue:info(Q,[consumers]) of [{consumers,X}]->X; _->0 end,
  case (binary:match(Nm,<<"queue.server.">>) =:= {0,13}) andalso (C > 0) of true->A+1; _->A end
end, 0, rabbit_amqqueue:list()),
PX = {resource,<<"/">>,exchange,<<"chat.proximity">>},
Bs = (catch rabbit_binding:list_for_source(PX)),
PlyN = case is_list(Bs) of
  true -> length(lists:usort(lists:filtermap(fun(Bd) ->
            case rabbit_amqqueue:lookup(element(4,Bd)) of
              {ok,Q} -> case rabbit_amqqueue:info(Q,[consumers]) of
                          [{consumers,C}] when C>0 -> {true,element(3,Bd)}; _->false end;
              _->false end end, Bs)));
  _ -> 0 end,
io:format("~p|~p~n",[SrvN,PlyN]).'
  out=$(_dune_rmqctl eval "$erl" 2>/dev/null | head -1)
  local srv="${out%%|*}" ply="${out#*|}"
  if [ -z "$srv" ] || [ "$srv" = "-1" ]; then
    echo "[command] status: query failed"
  else
    echo "[command] status: ${srv} map server(s) running, ${ply} player(s) online"
  fi
}

# _dune_shutdown_warning <Restart|Maintenance|Update> <minutes>
# Publishes a ServiceBroadcast/ServerShutdown title-card with a live countdown.
# Payload shape matches Funcom's send-dune-broadcast reference script:
#   Restart:           ShutdownType, ShutdownTimestamp, BroadcastDuration, LocalizedText
#   Maintenance/Update: ALSO DateTimestamp, ShutdownDuration
# Timestamps are unix seconds.
_dune_shutdown_warning() {
  local type="$1" mins="$2" title body native_body
  case "$type" in
    Restart)     title="SERVER RESTART"     native_body="Please find a safe location to log out. The server will be restarted in:" ;;
    Maintenance) title="SERVER MAINTENANCE" native_body="Please find a safe location to log out. The server will go down for maintenance in:" ;;
    Update)      title="SERVER UPDATE"      native_body="Please find a safe location to log out. The server will go down for an update in:" ;;
    *) echo "[command] usage: <type>-warning <minutes>"; return 1 ;;
  esac
  case "$mins" in
    ''|*[!0-9]*) echo "[command] usage: ${type,,}-warning <minutes>"; return 1 ;;
  esac
  if [ -z "${DUNE_SVC_CMD_TOKEN:-}" ]; then
    echo "[command] ${type,,}-warning unavailable: ServerCommands token not provisioned"
    return 1
  fi
  body="$native_body"
  local now ts secs payload tb bb erl res
  now=$(date +%s); secs=$((mins * 60)); ts=$((now + secs))
  tb=$(printf '%s' "$title" | base64 -w0 | tr -d '\n')
  bb=$(printf '%s' "$body"  | base64 -w0 | tr -d '\n')
  if [ "$type" = "Restart" ]; then
    payload='#{<<"ShutdownType">> => <<"Restart">>, <<"ShutdownTimestamp">> => __TS__, <<"BroadcastDuration">> => 60, <<"LocalizedText">> => [EnE, EnU]}'
  else
    payload='#{<<"ShutdownType">> => <<"__TYPE__">>, <<"ShutdownTimestamp">> => __TS__, <<"DateTimestamp">> => __TS__, <<"ShutdownDuration">> => __SECS__, <<"BroadcastDuration">> => 60, <<"LocalizedText">> => [EnE, EnU]}'
  fi
  payload=${payload//__TS__/$ts}
  payload=${payload//__TYPE__/$type}
  payload=${payload//__SECS__/$secs}
  erl=$(cat <<DUNE_ERL
Title = base64:decode(<<"${tb}">>),
Body  = base64:decode(<<"${bb}">>),
EnE = #{<<"Key">> => <<"en">>,    <<"Title">> => Title, <<"Body">> => Body},
EnU = #{<<"Key">> => <<"en-US">>, <<"Title">> => Title, <<"Body">> => Body},
Inner = iolist_to_binary(rabbit_json:encode(#{
  <<"ServerCommand">> => <<"ServiceBroadcast">>,
  <<"BroadcastType">> => <<"ServerShutdown">>,
  <<"BroadcastPayload">> => ${payload}})),
Outer = iolist_to_binary(rabbit_json:encode(#{
  <<"Version">> => 2, <<"AuthToken">> => <<"${DUNE_SVC_CMD_TOKEN}">>,
  <<"MessageContent">> => Inner})),
XName = rabbit_misc:r(<<"/">>, exchange, <<"heartbeats">>),
X = rabbit_exchange:lookup_or_die(XName),
MsgId = list_to_binary("cc-sw-" ++ integer_to_list(erlang:system_time(millisecond))),
P = {list_to_atom("P_basic"), <<"Content">>, undefined, [], undefined,
     undefined, undefined, undefined, undefined, MsgId, undefined,
     undefined, <<"fls">>, <<"fls_backend">>, undefined},
{ok, Msg} = rabbit_basic:message(XName, <<"notifications">>,
                                 rabbit_basic:build_content(P, Outer)),
io:format("~p~n", [rabbit_queue_type:publish_at_most_once(X, Msg)]).
DUNE_ERL
)
  res=$(_dune_rmqctl eval "$erl" 2>/dev/null | head -1 | tr -d '[:space:]')
  echo "[command] ${type,,}-warning ($res): ${mins}-min countdown - $title"
}

dune_cmd_restartwarning()     { _dune_shutdown_warning Restart     "${1:-}"; }
dune_cmd_maintenancewarning() { _dune_shutdown_warning Maintenance "${1:-}"; }
dune_cmd_updatewarning()      { _dune_shutdown_warning Update      "${1:-}"; }

# _dune_psql <args...> — psql against the game DB as the dune user, using
# the bundled postgres client + its musl libs (mirrors lib.sh's paths).
_dune_psql() {
  local pg; pg=$(rootfs postgres)
  LD_LIBRARY_PATH="$(ldlib postgres)" ICU_DATA="$(icu_dir postgres)" \
    "$pg/usr/local/bin/psql" -h 127.0.0.1 -p "${DUNE_PG_PORT:-15432}" \
    -U dune -d dune -v ON_ERROR_STOP=1 "$@"
}

# give-scout-orni <player name> — drop a full light-ornithopter parts kit
# (plus welding tool, large fuel canister and vehicle backup tool)
# into the named player's backpack. All-or-nothing, with safety checks:
#   * player must exist and be Offline (else UE5 overwrites our rows)
#   * backpack (inventory_type = 0) must have >= 13 free slots
# Parts go into the lowest free slots; existing items are never disturbed.
dune_cmd_give_scout_orni() {
  local name="$*"
  if [ -z "$name" ]; then
    echo "[command] usage: give-scout-orni <player name>"
    return 1
  fi
  local esc=${name//\'/\'\'}        # SQL-escape embedded single quotes
  local sql out rc note err
  sql=$(cat <<'DUNE_SQL'
DO $do$
DECLARE
  v_pawn bigint; v_status text; v_inv bigint; v_max int; v_free int;
BEGIN
  SELECT player_pawn_id, online_status INTO v_pawn, v_status
    FROM dune.player_state WHERE character_name = '__NAME__' LIMIT 1;
  IF v_pawn IS NULL THEN
    RAISE EXCEPTION 'no player named "%"', '__NAME__';
  END IF;
  IF v_status IS DISTINCT FROM 'Offline' THEN
    RAISE EXCEPTION 'player "%" is % - must be Offline', '__NAME__', v_status;
  END IF;
  SELECT id, max_item_count INTO v_inv, v_max
    FROM dune.inventories WHERE actor_id = v_pawn AND inventory_type = 0 LIMIT 1;
  IF v_inv IS NULL THEN
    RAISE EXCEPTION 'no backpack inventory for "%"', '__NAME__';
  END IF;
  IF v_max IS NULL OR v_max <= 0 THEN v_max := 35; END IF;
  SELECT count(*) INTO v_free FROM generate_series(0, v_max - 1) g
    WHERE g NOT IN (SELECT position_index FROM dune.items WHERE inventory_id = v_inv);
  IF v_free < 13 THEN
    RAISE EXCEPTION 'backpack has only % free slot(s), need 13', v_free;
  END IF;

  INSERT INTO dune.items
    (inventory_id, stack_size, position_index, template_id,
     is_new, acquisition_time, stats, quality_level)
  SELECT v_inv, 1, f.pos, p.template_id, true,
         EXTRACT(EPOCH FROM NOW())::bigint * 1000, p.stats, 0
  FROM (VALUES
    ( 1,'OrnithopterLightChassis_4',   '{}'::jsonb),
    ( 2,'OrnithopterLightHullFront_4', '{}'::jsonb),
    ( 3,'OrnithopterLightHullBack_4',  '{}'::jsonb),
    ( 4,'OrnithopterLightEngine_4',    '{}'::jsonb),
    ( 5,'OrnithopterLightGenerator_4', '{}'::jsonb),
    ( 6,'OrnithopterLightBoost_4',     '{}'::jsonb),
    ( 7,'OrnithopterLightLocomotion_4','{}'::jsonb),
    ( 8,'OrnithopterLightLocomotion_4','{}'::jsonb),
    ( 9,'OrnithopterLightLocomotion_4','{}'::jsonb),
    (10,'OrnithopterLightLocomotion_4','{}'::jsonb),
    (11,'RepairTool3','{"FCustomizationStats": [[], {}],"FItemStackAndDurabilityStats": [[], {"MaxDurability": 103.0,"CurrentDurability": 103.0,"DecayedMaxDurability": 103.0}]}'::jsonb),
    (12,'FuelCanister_Large','{}'::jsonb),
    (13,'VehicleBackupTool','{}'::jsonb)
  ) AS p(ord, template_id, stats)
  JOIN (
    SELECT g AS pos, row_number() OVER (ORDER BY g) AS rn
    FROM generate_series(0, v_max - 1) g
    WHERE g NOT IN (SELECT position_index FROM dune.items WHERE inventory_id = v_inv)
  ) AS f ON f.rn = p.ord;

  RAISE NOTICE 'OK gave 13 scout-ornithopter items to "%" (inv %, had % free slots)', '__NAME__', v_inv, v_free;
END
$do$;
DUNE_SQL
)
  sql=${sql//__NAME__/$esc}
  # if-condition keeps set -e (from lib.sh) from aborting on psql failure
  if out=$(_dune_psql -c "$sql" 2>&1); then rc=0; else rc=$?; fi
  if [ "$rc" -eq 0 ]; then
    note=$(printf '%s\n' "$out" | sed -n 's/^NOTICE:  OK //p' | head -1)
    echo "[command] give-scout-orni: ${note:-done for \"$name\"}"
  else
    err=$(printf '%s\n' "$out" | sed -n 's/^ERROR:  //p' | head -1)
    echo "[command] give-scout-orni failed: ${err:-unknown error (is Postgres up?)}"
  fi
  return 0
}

dune_cmd_help() {
  echo "[command] available commands:"
  echo "[command]   announce <title> | <message> [| <seconds>]"
  echo "[command]       title-card popup to every player (default 30s)"
  echo "[command]   players"
  echo "[command]       list connected players"
  echo "[command]   status"
  echo "[command]       server + player summary"
  echo "[command]   restart-warning <minutes>"
  echo "[command]       server-restart countdown title-card"
  echo "[command]   maintenance-warning <minutes>"
  echo "[command]       server-maintenance countdown title-card"
  echo "[command]   update-warning <minutes>"
  echo "[command]       server-update countdown title-card"
  echo "[command]   give-scout-orni <player name>"
  echo "[command]       light-orni kit + welder, fuel, backup tool (player offline)"
  echo "[command]   help"
}

# dune_dispatch <line> — route one console command line.
dune_dispatch() {
  local cmd rest
  read -r cmd rest <<< "$1"
  case "${cmd,,}" in
    announce|popup|an)              dune_cmd_announce "$rest" ;;
    players|who|list)               dune_cmd_players ;;
    status|stat)                    dune_cmd_status ;;
    restart-warning|rw)             dune_cmd_restartwarning "$rest" ;;
    maintenance-warning|mw)         dune_cmd_maintenancewarning "$rest" ;;
    update-warning|uw)              dune_cmd_updatewarning "$rest" ;;
    give-scout-orni|gso|orni)       dune_cmd_give_scout_orni "$rest" ;;
    help|\?)                        dune_cmd_help ;;
    "")                             ;;
    *) echo "[command] unknown command '$cmd' - type 'help'" ;;
  esac
}
